﻿namespace MovieRental
{
    public interface ICommand
    {
        void Execute();
    }
}